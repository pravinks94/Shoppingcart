package Controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.shoppingcart.model.UserDetails;

@Controller
@RequestMapping("/account.jsp")
public class FormController {
	
	@RequestMapping(method = RequestMethod.GET)
	public String initForm(Model model) {
		UserDetails form = new UserDetails();
		model.addAttribute("form", form);
		return "form";
	}

	@RequestMapping(method = RequestMethod.POST)
	public String submitForm(@Valid UserDetails form, BindingResult result) {
		String returnVal = "successForm";
		if(result.hasErrors()) {
			returnVal = "form";
		}
		return returnVal;
	}

}