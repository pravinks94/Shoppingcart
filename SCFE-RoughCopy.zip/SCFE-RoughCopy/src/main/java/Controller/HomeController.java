package Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	@RequestMapping("/")
	public String gohome(){
		return "index";
	}
	@RequestMapping("/account")
	public String goregister(){
		return "account";
	}
	@RequestMapping("/cust-product-list-men")
	public String goProdListMen(){
		return "cust-product-list-men";
	}
	@RequestMapping("/cust-product-list-women")
	public String goProdListWom(){
		return "cust-product-list-women";
	}@RequestMapping("/cust-product-list-shoes")
	public String goProdListShoe(){
		return "cust-product-list-shoes";
	}
	@RequestMapping("/contact")
	public String goContact(){
		return "contact";
	}
	

}
