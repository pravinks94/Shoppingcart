package Controller;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.niit.shoppingcart.model.InUsers;
import com.niit.shoppingcart.service.UserService;

@Controller
public class HomeController {
	static AnnotationConfigApplicationContext ctx;
	static UserService ude;
	static{
		ctx = new AnnotationConfigApplicationContext();
		ctx.scan("com.niit.shoppingcart");
		ctx.refresh();
		ude=(UserService) ctx.getBean("userService");
	}	
	@RequestMapping("/")
	public String gohome(){
		return "index";
	}
	@RequestMapping("/cust-product-list-men")
	public String goProdListMen(){
		return "cust-product-list-men";
	}
	@RequestMapping("/cust-product-list-women")
	public String goProdListWom(){
		return "cust-product-list-women";
	}
	@RequestMapping("/cust-product-list-shoes")
	public String goProdListShoe(){
		return "cust-product-list-shoes";
	}
	@RequestMapping("/contact")
	public String goContact(){
		return "contact";
	}
	@RequestMapping("/account")
	public String goregister(){
		return "account";
	}
	@RequestMapping("/cust-cart")
	public String goCustCart(){
		return "cust-cart";
	}
	@RequestMapping("/cust-checkout")
	public String goCustCheckout(){
		return "cust-checkout";
	}
	@RequestMapping("/cust-thankyou")
	public String goThankyou(){
		return "cust-thankyou";
	}
	@RequestMapping("/login")
	public String goLogin(){
		return "login";
	}

	@ModelAttribute("userdetailsobj")
	public InUsers getUserDetails(){
		return new InUsers();
	}
	@RequestMapping("/saveud")
	public String goadd1(@ModelAttribute("userdetailsobj")InUsers u){
		if(ude.addUser(u))
			return "index";
		else
			return "account";
	}

}
