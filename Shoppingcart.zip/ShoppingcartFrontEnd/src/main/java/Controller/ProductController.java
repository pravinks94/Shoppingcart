package Controller;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.service.ProductService;

@Controller
public class ProductController {
	static AnnotationConfigApplicationContext ctx;
	static ProductService pde;
	static {
		ctx = new AnnotationConfigApplicationContext();
		ctx.scan("com.niit.shoppingcart");
		ctx.refresh();
		pde = (ProductService) ctx.getBean("productService");
	}
	@RequestMapping("/admin-page-product")
	public ModelAndView goallProd() {
		ModelAndView prodmv = new ModelAndView("admin-page-product");
		prodmv.addObject("proddata", pde.getAllProducts());
		return prodmv;
	}
	@RequestMapping("/admin-page-product-addtemplate")
	public String goAdmProdAdd() {
		return "admin-page-product-addtemplate";
	}
	@ModelAttribute("prodobj")
	public Product getProductDetails() {
		return new Product();
	}
	@RequestMapping("/savepd")
	public String goaddProd(@ModelAttribute("prodobj")Product p)
	{
		return "admin-page-product";
	}

}
