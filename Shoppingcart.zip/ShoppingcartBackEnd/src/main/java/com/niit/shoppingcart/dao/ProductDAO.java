package com.niit.shoppingcart.dao;

import java.util.List;

import com.niit.shoppingcart.model.Product;

public interface ProductDAO {

	void addProduct(Product p);
	void delProduct(int pid);
	void updProduct(Product p);
	Product getProductById(int pid);
	List<Product> getAllProducts();
}
