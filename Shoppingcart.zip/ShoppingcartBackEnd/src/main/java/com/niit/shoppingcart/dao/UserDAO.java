package com.niit.shoppingcart.dao;

import java.util.List;

import com.niit.shoppingcart.model.InUsers;

public interface UserDAO {

	boolean addUser(InUsers u);
	boolean delUser(int uid);
	boolean updUser(InUsers u);
	InUsers getUserById(int uid); 
	List<InUsers> getAllUsers();
}
