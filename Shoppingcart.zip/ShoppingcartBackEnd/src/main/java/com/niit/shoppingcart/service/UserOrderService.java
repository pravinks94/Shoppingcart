package com.niit.shoppingcart.service;

import com.niit.shoppingcart.model.UserOrder;

public interface UserOrderService {

    void addUserOrder(UserOrder userOrder);

    double getUserOrderGrandTotal(int cartId);
}
