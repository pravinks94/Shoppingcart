package com.niit.shoppingcart.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.CartItem;
import com.niit.shoppingcart.model.InUsers;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.UserOrder;
import com.niit.shoppingcart.service.CartItemService;
import com.niit.shoppingcart.service.CartItemServiceImpl;
import com.niit.shoppingcart.service.CartService;
import com.niit.shoppingcart.service.CartServiceImpl;
import com.niit.shoppingcart.service.ProductService;
import com.niit.shoppingcart.service.ProductServiceImpl;
import com.niit.shoppingcart.service.UserOrderService;
import com.niit.shoppingcart.service.UserOrderServiceImpl;
import com.niit.shoppingcart.service.UserService;
import com.niit.shoppingcart.service.UserServiceImpl;

@Configuration
@ComponentScan("com.niit")
@EnableTransactionManagement
public class ApplicationContextConfig {

	@Autowired
	@Bean(name = "dataSource")
	public DataSource getDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("org.h2.Driver");
		dataSource.setUrl("jdbc:h2:tcp://localhost/~/test1");

		dataSource.setUsername("sa");
		dataSource.setPassword("");
		return dataSource;
	}
    
   
    private Properties getHibernateProperties() {
    	Properties properties = new Properties();
    	properties.put("hibernate.show_sql", "false");
     	properties.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
     	properties.put("hibernate.hbm2ddl.auto", "update");
    	return properties;
    }
    
    @Autowired
    @Bean(name = "sessionFactory")
    public SessionFactory getSessionFactory(DataSource dataSource) {
    	LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
    	sessionBuilder.addProperties(getHibernateProperties());
    	sessionBuilder.addAnnotatedClass(Cart.class);
    	sessionBuilder.addAnnotatedClass(CartItem.class);
    	sessionBuilder.addAnnotatedClass(InUsers.class);
    	sessionBuilder.addAnnotatedClass(Product.class);
    	sessionBuilder.addAnnotatedClass(UserOrder.class);
      	return sessionBuilder.buildSessionFactory();
    }
    
	@Autowired
	@Bean(name = "transactionManager")
	public HibernateTransactionManager getTransactionManager(SessionFactory sessionFactory) {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager(sessionFactory);
		return transactionManager;
	}
	
	@Autowired
	@Bean(name="userService")
	public UserService getUserService(){
		return new UserServiceImpl();
	}

	@Autowired
	@Bean(name="cartItemService")
	public CartItemService getCartItemService(){
		return new CartItemServiceImpl();
	}
	
	@Autowired
	@Bean(name="cartService")
	public CartService getCartService(){
		return new CartServiceImpl();
	}
	
	@Autowired
	@Bean(name="productService")
	public ProductService getProductService(){
		return new ProductServiceImpl();
	}
	
	@Autowired
	@Bean(name="userOrderService")
	public UserOrderService getUserOrderService(){
		return new UserOrderServiceImpl();
	}
}
