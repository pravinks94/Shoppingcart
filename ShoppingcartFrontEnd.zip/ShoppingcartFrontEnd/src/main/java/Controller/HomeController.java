package Controller;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.niit.shoppingcart.dao.UserDetailsDAO;
import com.niit.shoppingcart.model.UserDetails;

@Controller
public class HomeController {
	static AnnotationConfigApplicationContext ctx;
	static UserDetailsDAO ude;
	
	static{
		ctx = new AnnotationConfigApplicationContext();
		ctx.scan("com.niit.shoppingcart");
		ctx.refresh();
		ude=(UserDetailsDAO) ctx.getBean("userDetailsDAO");
	}
	//private UserDetails ud;
	
	@RequestMapping("/")
	public String gohome(){
		return "index";
	}
	
	@RequestMapping("/cust-product-list-men")
	public String goProdListMen(){
		return "cust-product-list-men";
	}
	@RequestMapping("/cust-product-list-women")
	public String goProdListWom(){
		return "cust-product-list-women";
	}
	@RequestMapping("/cust-product-list-shoes")
	public String goProdListShoe(){
		return "cust-product-list-shoes";
	}
	@RequestMapping("/contact")
	public String goContact(){
		return "contact";
	}
	@RequestMapping("/account")
	public String goregister(){
		return "account";
	}
	@RequestMapping("/cust-cart")
	public String goCustCart(){
		return "cust-cart";
	}
	@RequestMapping("/cust-checkout")
	public String goCustCheckout(){
		return "cust-checkout";
	}

	@ModelAttribute("userdetailsobj")
	public UserDetails getUserDetails(){
		return new UserDetails();
	}
	@RequestMapping("/saveud")
	public String goadd1(@ModelAttribute("userdetailsobj")UserDetails u){
		if(ude.addUser(u))
			return "index";
		else
			return "account";
	}

}
