package Controller;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Product;


@Controller
public class AdminController {
	static AnnotationConfigApplicationContext ctx;
	static ProductDAO pde;
	static CategoryDAO cde;
	static{
		ctx = new AnnotationConfigApplicationContext();
		ctx.scan("com.niit.shoppingcart");
		ctx.refresh();
		pde=(ProductDAO) ctx.getBean("ProductDAO");
		cde=(CategoryDAO) ctx.getBean("CategoryDAO");
	}
	@RequestMapping("/admin-homepage")
	public String goAdmHome(){
		return "admin-homepage";
	}
	@RequestMapping("/admin-page-category")
	public String goAdmCate(){
		return "admin-page-category";
	}  
	@RequestMapping("/admin-page-product")
	public String goAdmProd(){
		return "admin-page-product";
	}
	@RequestMapping("/admin-page-supplier")
	public String goAdmSupp(){
		return "admin-page-supplier";
	}
	@RequestMapping("/admin-page-product-addtemplate")
	public String goAdmProdAdd(){
		return "admin-page-product-addtemplate";
	}
	@ModelAttribute("prodobj")
	public Product getProductDetails(){
		return new Product();
	}
	@RequestMapping("/savepd")
	public ModelAndView doadd(@ModelAttribute("prodobj")Product p,HttpServletRequest req){
		ModelAndView m=new ModelAndView("admin-page-product");
		if(pde.addProd(p))
			if(!p.getFile().isEmpty())
			{
				String prd1=req.getSession().getServletContext().getRealPath("/");
				File f=new File(prd1+"/resources/img/uploadedimg/");
				if(!f.exists())
					f.mkdirs();
				Path path =Paths.get(prd1+"/resources/img/uploadedimg/"+p.getName()+".jpg");
				try{
					p.getFile().transferTo(new File(path.toString()));
					System.out.println(path.toString());
				}catch(Exception e){
				}
			}
			else
			{
				m.setViewName("admin-page-product");
				
				
			}
			return m;
		
	}
	public ModelAndView goallProd(){
		ModelAndView prodmv = new ModelAndView("admin-page-product");
		prodmv.addObject("proddata", pde.getAllProds());
		return prodmv;
	}

	@RequestMapping("/delProd")
	public String godelprod1(HttpServletRequest req){
		int id=Integer.parseInt(req.getParameter("pid"));
		if(pde.delProd(id))
			return "admin-page-product";
		else
			return "admin-page-product";
	}
	@ModelAttribute("cateobj")
	public Category getCategoryDetails(){
		return new Category();
	}
	@RequestMapping("/savecd")
	public String goaddCate1(@ModelAttribute("cateobj")Category c){
		if(cde.addCat(c))
			return "admin-page-category";
		else
			return "admin-page-category";
	}

}
