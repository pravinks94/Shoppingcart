package Controller;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Product;

@Controller
public class AdminController {
	@RequestMapping("/admin-homepage")
	public String goAdmHome(){
		return "admin-homepage";
	}
	@RequestMapping("/admin-page-category")
	public String goAdmCate(){
		return "admin-page-category";
	}
	@RequestMapping("/admin-page-product")
	public String goAdmProd(){
		return "admin-page-product";
	}
	@RequestMapping("/admin-page-product-addtemplate")
	public String goAdmProdAdd(){
		return "admin-page-product-addtemplate";
	}
	static AnnotationConfigApplicationContext ctx;
	static ProductDAO pde;
	
	static{
		ctx = new AnnotationConfigApplicationContext();
		ctx.scan("com.niit.shoppingcart");
		ctx.refresh();
		pde=(ProductDAO) ctx.getBean("ProductDAO");
	}
	@ModelAttribute("prodobj")
	public Product getProductDetails(){
		return new Product();
	}
	@RequestMapping("/savepd")
	public String goadd1(@ModelAttribute("prodobj")Product p){
		if(pde.addProd(p))
			return "admin-page-product";
		else
			return "admin-page-product-addtemplate";
	}

}
