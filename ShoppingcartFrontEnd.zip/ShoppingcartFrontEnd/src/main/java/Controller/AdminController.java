package Controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AdminController {
	@RequestMapping("/admin-homepage")
	public String goAdmHome() {
		return "admin-homepage";
	}

	@RequestMapping("/admin-page-category")
	public String goAdmCate() {
		return "admin-page-category";
	}
	@RequestMapping("/admin-page-supplier")
	public String goAdmSupp() {
		return "admin-page-supplier";
	}
}
	
	
	/*public ModelAndView goaddProd(@ModelAttribute("prodobj")Product p,HttpServletRequest req){
		m=new ModelAndView("redirect:/admin-page-product");
		if(pde.addProduct(p))
			if(!p.getFile().isEmpty())
			{
				String a=req.getSession().getServletContext().getRealPath("/");
				File f=new File(a+"\\resources\\img\\uploadedimg\\");
				if(!f.exists())
					f.mkdirs();
				Path path=Paths.get(a+"\\resources\\img\\uploadedimg\\"+p.getProductId()+".jpg");
				try{
					p.getFile().transferTo(new File(path.toString()));
					System.out.println(path.toString());
				}catch(Exception e){
					System.out.println("You failed to upload"+p.getId()+"because the file was empty");
				}
			return m;
			}
			else
				m.setViewName("admin-page-product-addtemplate");
				return m;
	} */

	

