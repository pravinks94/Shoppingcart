package Controller;
import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Product;


@Controller
public class AdminController {
	static AnnotationConfigApplicationContext ctx;
	static ProductDAO pde;
	static CategoryDAO cde;
	static{
		ctx = new AnnotationConfigApplicationContext();
		ctx.scan("com.niit.shoppingcart");
		ctx.refresh();
		pde=(ProductDAO) ctx.getBean("ProductDAO");
		cde=(CategoryDAO) ctx.getBean("CategoryDAO");
	}
	@RequestMapping("/admin-homepage")
	public String goAdmHome(){
		return "admin-homepage";
	}
	@RequestMapping("/admin-page-category")
	public String goAdmCate(){
		return "admin-page-category";
	}  
	@RequestMapping("/admin-page-product")
	public ModelAndView goallProd(){
		ModelAndView prodmv = new ModelAndView("admin-page-product");
		prodmv.addObject("proddata", pde.getAllProds());
		return prodmv;
	}
	@RequestMapping("/admin-page-supplier")
	public String goAdmSupp(){
		return "admin-page-supplier";
	}
	@RequestMapping("/admin-page-product-addtemplate")
	public String goAdmProdAdd(){
		return "admin-page-product-addtemplate";
	}
	@ModelAttribute("prodobj")
	public Product getProductDetails(){
		return new Product();
	}
	@RequestMapping("/savepd")
	public String goaddProd(@ModelAttribute("prodobj")Product p){
		System.out.println(p.getName()+"\t"+p.getDescr1());
		if(pde.addProd(p))
			return "admin-page-product";
		else
			return "admin-page-product-addtemplate";
	}

	@RequestMapping("/delProd")
	public String godelprod1(HttpServletRequest req){
		int id=Integer.parseInt(req.getParameter("pid"));
		if(pde.delProd(id))
			return "admin-page-product";
		else
			return "admin-page-product";
	}
	@ModelAttribute("cateobj")
	public Category getCategoryDetails(){
		return new Category();
	}
	@RequestMapping("/savecd")
	public String goaddCate1(@ModelAttribute("cateobj")Category c){
		if(cde.addCat(c))
			return "admin-page-category";
		else
			return "admin-page-category";
	}

}
